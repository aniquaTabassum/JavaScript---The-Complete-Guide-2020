var divBox = document.querySelector("div")
console.dir(document.getElementById("main-box"))